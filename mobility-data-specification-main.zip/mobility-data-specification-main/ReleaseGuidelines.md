# MDS Release Guidelines

MDS will see regular updates and new [releases](https://github.com/openmobilityfoundation/mobility-data-specification/releases).

**See the new [MDS Release Guidelines](https://github.com/openmobilityfoundation/governance/blob/main/technical/ReleaseGuidelines.md) document for details.**

