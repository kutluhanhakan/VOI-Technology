# MDS Contributor Guidelines

**See the new [MDS Contributor Guidelines](https://github.com/openmobilityfoundation/governance/blob/main/CONTRIBUTING.md) document for details.**
